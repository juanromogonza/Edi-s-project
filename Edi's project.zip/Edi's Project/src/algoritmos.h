/*
 * Algoritmos.h
 *
 *  Created on: 03/03/2019
 *      Author: Profesores de EDI
 */

#ifndef ALGORITMOS_H_
#define ALGORITMOS_H_

#include "ConjuntoBarrios.h"

class Algoritmos {

private:
	// atributo, puntero a la clase conjunto de barrios
	ConjuntoBarrios *cB;

	// carga los datos desde los ficheros de texto

	/*PRE:
	 * POST: Carga los datos desde los ficheros de texto
	 * Complejidad: O(logn²)
	 */
	void cargarDatos();
	// ejecuta todos los algoritmos del proyecto
	void run();

public:

	Algoritmos();

	/*PRE:Los atributos contengan un dato válido
	 * POST:Muestra por pantalla todas los barrios del vector.
	 * Complejidad: O(n*logn)
	 * Parámetros:
	 */
	void mostrarBarrios();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 * POST: Carga todas las vías que hay en Via.csv, insertándolos en orden en la lista de Vías l.
	 * Complejidad: O(logn²)
	 */
	void cargarVias();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 * POST: Carga todos los barrios que hay en Barrio.csv, insertándolos en orden en el barrio auxliar creado en el método
	 * Complejidad: O(logn²)
	 */
	void cargarBarrios();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 * POST: Carga todos los árboles que hay en Arbol.csv, insertándolos en orden en la lista de árboles lA.
	 * Complejidad: O(logn²)
	 */
	void cargarArboles(Arbol *a);

	/*PRE:Los atributos contengan un dato válido
	 * POST: Asigna los valores del fichero Arbol.csv a un arbol auxiliar para su posterior inserción.
	 * Complejidad: O(n*logn²)
	 * Parámetros:
	 */
	void cargarArbolesFichero();

	/*PRE:Los atributos contengan un dato válido
	 * POST: Asigna las vías en orden por nombre en el barrio al que corresponda
	 * Complejidad: O(n*logn²)
	 * Parámetros:
	 */
	void cargarViaEnBarrio(Via *v);

	/*PRE:Los atributos contengan un dato válido
	 * POST: Genera un fichero con los árboles pertenecientes a una vía, la cual corresponde con la variable nombreVia.
	 * Complejidad: O(n*logn²)
	 * Parámetros:	nombreVia: Contiene el nombre de la via para generar el fichero.
	 */
	void generarFicheroArboles1(string nombreVia);

	/*PRE:Los atributos contengan un dato válido.
	 * POST: Obtiene el número de árboles totales de cada especie para su posterior inserción en el fichero "Total Arboles"
	 * Complejidad: O(n*logn²)
	 * Parámetros:
	 */
	void generarFicheroNumeroArboles3();

	/*PRE:Los atributos contengan un dato válido.
	 * POST: Muestra el número de árboles por barrio.
	 * Complejidad: O(n*logn²)
	 * Parámetros:
	 */
	void mostrarNumeroArbolesEnBarrio4();

	/*PRE:Los atributos contengan un dato válido.
	 * POST: Guarda en la cola generada cA los árboles que cumplen los requisitos para su poda y se muestran por pantalla.
	 * Complejidad: O(n*logn²)
	 * Parámetros:
	 */
	void arbolesAPodar2(string genero);

	/*PRE:Los atributos contengan un dato válido.
	 * POST: Muestra los árboles y la vía a la que corresponden de la cola que entra por parámetros.
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	void mostrarAlgoritmo2(Cola<ColaArbol*>*& cA);

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Realiza la llamada al módulo que genera el fichero de árboles de una vía.
	 * Complejidad: O(n)
	 */
	void algoritmo1(string nombreVia);

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Realiza la llamada al módulo que indica los árboles a podar
	 * Complejidad: O(n)
	 */
	void algoritmo2(string genero);

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Realiza la llamada al módulo que genera el fichero  que indica el número total de arboles.
	 * Complejidad: O(n)
	 */
	void algoritmo3();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Realiza la llamada al módulo que muestra el número de árboles por barrio.
	 * Complejidad: O(n)
	 */
	void algoritmo4();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Realiza la llamada a los módulos de pruebas.
	 * Complejidad: O(n)
	 */




	void JuegoPruebas();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de insertar arbol en via.
	 * Complejidad: O(log n)
	 */
	void pruebaBarrioInsertarArbolenVia();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de existeVia.
	 * Complejidad: O(log n)
	 */
	void pruebaBarrioExisteVia();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de insertarVia.
	 * Complejidad: O(log n )
	 */
	void pruebaBarrioInsertar();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de cuantosarboles.
	 * Complejidad: O(log n)
	 */
	void pruebaBarrioCuantosArboles();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en via de insertarArbol.
	 * Complejidad: O()
	 */
	void pruebaViaInsertarArbol();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de cargarArbolesEnFichero.
	 * Complejidad: O(log(n))
	 */
	void pruebaViaCargarArbolesEnFichero();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de recorrerListaVia.
	 * Complejidad:  O(n*logn).
	 */
	void pruebaBarrioRecorrerListaVia();

	/*PRE:Los atributos contengan datos válidos y estén correctamente inicializados.
	 *POST: Prueba el módulo en barrio de cargarListaEspecie.
	 * Complejidad: O(n³)
	 */
	void pruebaBarrioCargarListaEspecie();
	//Destructor:
	~Algoritmos();

};

#endif /* ALGORITMOS_H_ */
