/*
 * Via.cpp
 *
 *  Created on: 11 mar. 2019
 *      Author: Juan Romo González
 */

#include "Via.h"

Via::Via() {
	this->codBarrio = 0;
	this->codVia = 0;
	this->longitud = 0.0;
	this->nombreVia = "";
	this->tipoVia = "";
	this->lA = NULL;
}

Via::Via(int codBarrio, string nombreVia, float longitud, string tipoVia,
		int codVia) {
	this->codBarrio = codBarrio;
	this->codVia = codVia;
	this->longitud = longitud;
	this->nombreVia = nombreVia;
	this->tipoVia = tipoVia;
	this->lA = NULL;
}

int Via::getCodBarrio() const {
	return codBarrio;
}

void Via::setCodBarrio(int codBarrio) {
	this->codBarrio = codBarrio;
}

const string& Via::getNombreVia() const {
	return nombreVia;
}

void Via::setNombreVia(const string& nombreVia) {
	this->nombreVia = nombreVia;
}

float Via::getLongitud() const {
	return longitud;
}

void Via::setLongitud(float longitud) {
	this->longitud = longitud;
}

const string& Via::getTipoVia() const {
	return tipoVia;
}

void Via::setTipoVia(const string& tipoVia) {
	this->tipoVia = tipoVia;
}

int Via::getCodVia() const {
	return codVia;
}

void Via::setCodVia(int codVia) {
	this->codVia = codVia;
}

void Via::mostrarVia() {
	cout << this->nombreVia << ", ";
}

//------------------------------Módulos para la carga de datos-------------------------------------------------------------------------------------------------------------
void Via::insertarArbol(Arbol* a) { //comprueba si la lista de arboles esta vacia y, si lo esta, crea una nueva. Luego, (o si la lista tenia al menos un elemento) inserta el nuevo elemento en la posicion marcada por el PI y lo avanza una posicion
	if (lA == NULL)
		lA = new ListaPI<Arbol*>();
	this->lA->insertar(a);
	this->lA->avanzar();
}

//------------------------------Módulo para algoritmo 1-----------------------------------------------------------------------------------------------------------------
void Via::cargarArbolesEnFichero1() { //crea un fichero con el nombre de la via y escribe todos los atributos de todos los arboles de la lista de arboles de esa via
	ofstream f(this->getNombreVia().c_str());
	Arbol *a;
	if (this->lA != NULL) {
		this->lA->moverInicio();
		while (!this->lA->finLista()) {
			this->lA->consultar(a);
			f << a->getNombreComun() << ';';
			f << a->getAltura() << ';';
			f << a->getCodVia() << ';';
			f << a->getCopa() << ';';
			f << a->getDiametro() << ';';
			f << a->getEspecie() << ';';
			f << a->getFamilia() << ';';
			f << a->getGenero() << ';';
			f << a->getRiego() << ';';
			f << a->getUnidad() << endl;
			this->lA->avanzar();
		}
	}
	f.close();
}

//----------------------------------Módulos para algoritmo 2--------------------------------------------------------------------------------------------------------
void Via::recorrerListaArbol2(string genero, Cola<ColaArbol*>*& cA) {
	if (this->lA != NULL) {
		Arbol *a;
		this->lA->moverInicio();
		while (!this->lA->finLista()) {
			this->lA->consultar(a);
			if (a->getGenero() == genero && a->getAltura() > 5
					&& a->getCopa() > 3) {
				ColaArbol *c = new (ColaArbol); //puntero tipo struct ColaArbol apunta a un nuevo nodo tipo struct ColaArbol
				c->a = a;
				c->nombreVia = this->nombreVia;
				this->insertarColaPrioridad2(c, cA);
			}
			this->lA->avanzar();
		}
	}
}

void Via::insertarColaPrioridad2(ColaArbol *c, Cola<ColaArbol*>*& cA) {
	ColaArbol *caux;
	Cola<ColaArbol*>*caux2 = new Cola<ColaArbol*>();
	bool enc = false;

	if (cA->vacia())
		cA->encolar(c);

	else {
		while (!cA->vacia()) {
			cA->primero(caux);
			cA->desencolar();
			if (c->a->getAltura() > caux->a->getAltura() && !enc) {
				enc = true;
				caux2->encolar(c);
			} else {
				if (c->a->getAltura() == caux->a->getAltura() && !enc) {
					if (c->a->getCopa() >= caux->a->getCopa()) {
						enc = true;
						caux2->encolar(c);
					}
				}
			}
			caux2->encolar(caux);
		}
		if (!enc)
			caux2->encolar(c);

		this->reordenarCola(caux2, cA);
	}
	if (caux2 != NULL)
		delete caux2;
}

void Via::reordenarCola(Cola<ColaArbol*>* caux, Cola<ColaArbol*>*& cA) {
	ColaArbol *c;
	if (!caux->vacia()) {
		caux->primero(c);
		caux->desencolar();
		cA->encolar(c);
		reordenarCola(caux, cA);
	}
}
//--------------------------------------Módulo para algoritmo 3---------------------------------------------------------------------------------------------------------------------------
void Via::cargarListaEspecie3(ListaPI<Especie*>*& lE) {
	Especie *e;
	Arbol *a;
	if (this->lA != NULL) {
		this->lA->moverInicio();

		if (lE->estaVacia()) { //si la lista de especies esta vacia, crea una nueva especie, la carga con los datos de la lista de arboles y avanza ambas listas al siguiente nodo
			this->lA->consultar(a);
			e = new Especie();
			e->cont = a->getUnidad();
			e->especie = a->getEspecie();
			lE->insertar(e);
			lE->avanzar();
			this->lA->avanzar();
		} //hasta aqui es, solo si la lista de especies esta vacia, insertar el primer elemento. Si no nada.

		while (!this->lA->finLista()) {
			this->lA->consultar(a);
			lE->moverInicio();
			bool esta = false;
			while (!lE->finLista() && !esta) { //comprueba las especies de la lista de especies hasta que encuentra la que coincide con la especie del arbol o se acaba la lista
				lE->consultar(e);
				if (e->especie == a->getEspecie()) { //si el arbol que esta comprobando en ese momento es de una especie ya registrada, suma el numero de arboles a esa especie y sigue registrando el resto de la lista de especies
					e->cont += a->getUnidad();
					esta = true;
				}
				lE->avanzar();
			}
			if (!esta) { //si el bucle anterior acaba y la especie del arbol comprobado no existe en la lista, se agrega y se añade el numero de arboles de ese arbol comprobado
				e = new Especie();
				e->cont = a->getUnidad();
				e->especie = a->getEspecie();
				this->insertarEnOrdenEspecie3(e, lE);
			}
			this->lA->avanzar();
		}
	} //cierre del primer if
}

void Via::insertarEnOrdenEspecie3(Especie* e, ListaPI<Especie*>*& lE) { //coloca la nueva especie por orden alfabetico
	lE->moverInicio();
	bool enc = false;
	Especie *eaux;
	while (!lE->finLista() && !enc) {
		lE->consultar(eaux);
		if (eaux->especie > e->especie)
			enc = true;
		else
			lE->avanzar();
	}
	lE->insertar(e);
}

//--------------------------------------Módulo para algoritmo 4------------------------------------------------------------------------------------------------------
int Via::cuantosArboles() { //devuelve todos los arboles de una via
	int cont = 0;
	Arbol *a;
	if (this->lA != NULL) {
		this->lA->moverInicio();
		while (!this->lA->finLista()) {
			this->lA->consultar(a); //consultar apunta el puntero a donde apunta el PI
			cont += a->getUnidad();
			this->lA->avanzar();
		}
	}
	return cont;
}

//------------------------------------Destructor-----------------------------------------------------------------------------------------------------------------------------
Via::~Via() {
	Arbol *a;
	if (this->lA != NULL) {
		this->lA->moverInicio();
		while (!this->lA->finLista()) {
			this->lA->consultar(a);
			this->lA->borrar();
			delete a;
		}
		delete this->lA;
	}
}

