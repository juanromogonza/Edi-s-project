/*
 * Via.h
 *
 *  Created on: 11 mar. 2019
 *      Author: Juan Romo González
 */

#ifndef VIA_H_
#define VIA_H_
#include "Arbol.h"
#include "listapi.h"
#include "cola.h"
#include <fstream>
#include <cstdlib>

struct Especie {
	string especie;
	int cont;
};
struct ColaArbol {
	Arbol *a;
	string nombreVia;
};

class Via {
	int codBarrio;
	string nombreVia;
	float longitud;
	string tipoVia;
	int codVia;
	ListaPI<Arbol*>*lA;

public:

	/*PRE:
	 * POST: Inicializa las variables declaradas en la clase a 0
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	Via();

	/*PRE: Los parámetros deben contener datos válidos
	 * POST: Los atributos se inicializan correctamente
	 * Complejidad: O(1).
	 * Parámetros: codBarrio: código del barrio
	 * 			   nombreVia: nombre de la vía
	 * 			   longitud: longitud de la vía
	 * 			   tipoVia: tipo de la vía(Calle, avenida, etc.)
	 * 			   codVia: código de la vía
	 */
	Via(int codBarrio, string nombreVia, float longitud, string tipoVia,
			int codVia);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el código del barrio
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	int getCodBarrio() const;

	/*PRE: Que entre por parámetros de entrada el código del barrio que se le va a asignar correctamente
	 * POST: Asigna al código del barrio la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: codBarrio: indica el codigo del barrio.
	 */
	void setCodBarrio(int codBarrio);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el nombre de la vía
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	const string& getNombreVia() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al nombre de la via la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: nombreVia: indical  el nombre de la vía.
	 */
	void setNombreVia(const string& nombreVia);

	/*PRE:El atributo contenga un dato válido
	 * POST:Devuelve la longitud de la vía
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	float getLongitud() const;

	/*PRE: Que entre por parámetros de entrada la longitud de la vía que se le va a asignar correctamente
	 * POST: Asigna a la longitud de la via la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: longitud: indical  la longitud de la vía.
	 */
	void setLongitud(float longitud);

	/*PRE:El atributo contenga un dato válido
	 * POST:Devuelve el tipo de la vía
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	const string& getTipoVia() const;

	/*PRE: Que entre por parámetros de entrada el tipo de la vía que se le va a asignar correctamente
	 * POST: Asigna al tipo de la via la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: nombreVia: indical  el nombre de la vía.
	 */
	void setTipoVia(const string& tipoVia);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el código de la vía
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	int getCodVia() const;

	/*PRE: Que entre por parámetros de entrada el código de la vía que se le va a asignar correctamente
	 * POST: Asigna al código de la via la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: codVia: indica el codigo de la vía.
	 */
	void setCodVia(int codVia);

	/*PRE: Los atributos contengan datos válidos
	 * POST: Muestra por pantalla las variables de la clase Vía
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	void mostrarVia();

//------------------------------Módulos para la carga de datos-------------------------------------------------------------------------------------------------------------

	/*PRE: Los atributos contenga datos válidos.
	 * POST: Inserta el árbol que viene por parámetros en la lista lA.
	 * Complejidad:O(1)
	 * Parametros:
	 */
	void insertarArbol(Arbol *a);

//-----------------------------------------Modulos algoritmo 1-----------------------------------------

	/*PRE: Los atributos contenga datos válidos y el flujo haya sido abierto correctamente.
	 * POST: Carga en el fichero f todos los árboles que haya en la vía v, que viene dada por parámetros.
	 * Complejidad: O(1)
	 * Parametros:
	 */
	void cargarArbolesEnFichero1();

//-----------------------------------------Modulos algoritmo 2-----------------------------------------

	/*PRE: Los atributos contenga datos válidos.
	 * POST: Recorre la lista de arboles y encuentra el lugar de insercion segun el genero pasado por parametros
	 * Complejidad: O(logn)
	 * Parametros:
	 */
	void recorrerListaArbol2(string genero, Cola<ColaArbol*>*& cA);//si se usa este algoritmo, se usan insertarColaPrioridad2 por estar dentro y, a su vez recolocarCola() por estar dentro de insertarColaPrioridad2()

	/*PRE: Los atributos contenga datos válidos.
	 * POST: Inserta los arboles en una cola priorizando primero su altura y luego el tamaño de su copa
	 * Complejidad: O(logn)
	 * Parametros:
	 */
	void insertarColaPrioridad2(ColaArbol *c, Cola<ColaArbol*>*&cA);

	/*PRE: Los atributos contenga datos válidos.
		 * POST:
		 * Complejidad: O()
		 * Parametros:
		 */
	void reordenarCola(Cola<ColaArbol*> *caux,Cola<ColaArbol*>*& cA);

//-----------------------------------------Modulos algoritmo 3-----------------------------------------

	/*PRE: Los atributos contenga datos válidos.
	 * POST:
	 * Complejidad: O(n*logn)
	 * Parametros:
	 */
	void cargarListaEspecie3(ListaPI<Especie*>*&lE);

	/*PRE: Los atributos contenga datos válidos.
	 * POST: Inserta en orden la especie del arbol dentro de la lista de especies
	 * Complejidad: O(logn)
	 * Parametros:
	 */
	void insertarEnOrdenEspecie3(Especie *e, ListaPI<Especie*>*& lE);//esta dentro de cargarListaEspecie3

//-----------------------------------------Modulos algoritmo 4-------------------------------------------------------------

	/*PRE: Los atributos contenga datos válidos.
	 * POST: Devuelve el número total de elementos de la lista lA.
	 * Complejidad: O(n)
	 * Parametros:
	 */
	int cuantosArboles();

//---------------------------Destructor-----------------------------------

	/*PRE:
	 * POST:Libera memoria
	 * Complejidad: O(n)
	 * Parámetros:
	 */
	~Via();
};

#endif /* VIA_H_ */
