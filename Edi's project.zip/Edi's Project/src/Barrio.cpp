/*
 * Barrio.cpp
 *
 *  Created on: 12 mar. 2019
 *      Author: Juan Romo González
 */

#include "Barrio.h"

Barrio::Barrio() {
	this->area = 0.0;
	this->codigo = 0;
	this->distrito = "";
	this->nombre = "";
	this->perimetro = 0.0;
	this->l = NULL;
}

Barrio::Barrio(string nombre, float area, float perimetro, int codigo,
		string distrito) {
	this->area = area;
	this->codigo = codigo;
	this->distrito = distrito;
	this->nombre = nombre;
	this->perimetro = perimetro;
	this->l = NULL;
}

const string& Barrio::getNombre() const {
	return nombre;
}

void Barrio::setNombre(const string& nombre) {
	this->nombre = nombre;
}

float Barrio::getArea() const {
	return area;
}

void Barrio::setArea(float area) {
	this->area = area;
}

float Barrio::getPerimetro() const {
	return perimetro;
}

void Barrio::setPerimetro(float perimetro) {
	this->perimetro = perimetro;
}

int Barrio::getCodigo() const {
	return codigo;
}

void Barrio::setCodigo(int codigo) {
	this->codigo = codigo;
}

const string& Barrio::getDistrito() const {
	return distrito;
}

void Barrio::setDistrito(const string& distrito) {
	this->distrito = distrito;
}

void Barrio::mostrar() {
	cout << "Área: " << this->area << "  Código: " << this->codigo
			<< "  Distrito: " << this->distrito << "  Nombre: " << this->nombre
			<< "|| Vías: ";

	Via *v2;
	if (l != NULL) {
		this->l->moverInicio();
		while (!l->finLista()) {
			this->l->consultar(v2);
			v2->mostrarVia();
			l->avanzar();
		}
	}
	cout << endl;
}

//-----------------------------------Modulos para carga de datos---------------------------------------------------------------------------------------------------------------------------------------------------------

void Barrio::insertarArbolEnVia(Arbol* a) {
	Via *vaux;
	bool enc = false;
	if (this->l != NULL) {
		this->l->moverInicio();
		while (!this->l->finLista() && !enc) {
			this->l->consultar(vaux);
			if (vaux->getCodVia() == a->getCodVia()) {
				enc = true;
				vaux->insertarArbol(a);
			} else
				this->l->avanzar();
		}
	}
}

void Barrio::insertar(Via* v) {

	bool enc = false;
	Via *vaux;
	if (this->l == NULL)
		this->l = new ListaPI<Via*>();
	this->l->moverInicio();
	while (!this->l->finLista() && !enc) { //si l esta a NULL, finLista() devuelve true porque finLista() comprueba si el PI esta a NULL (fin de la lista). Entonces, el bucle no se hace y directamente inserta un nuevo elemento
		this->l->consultar(vaux);
		if (vaux->getNombreVia() > v->getNombreVia()) {
			enc = true;

		} else {
			this->l->avanzar();
		}
	}
	this->l->insertar(v);
}

//-------------------------------Módulos para algoritmo 1------------------------------------------------------------------------------------------------

void Barrio::obtenerVia1(string nombre, Via *&v, bool &enc) {
	if (this->l != NULL) {
		this->l->moverInicio();
		while (!this->l->finLista() && !enc) {
			this->l->consultar(v);
			if (v->getNombreVia() == nombre) {
				if (v->cuantosArboles() > 0) { //Para saber si en la vía existen árboles
					enc = true;
					v->cargarArbolesEnFichero1(); //En el momento en el que encuentre la vía que coincida con el nombre de la via dado por parámetros, escribo en un fichero todos los árboles de la vía
				} else
					this->l->avanzar();

			} else
				this->l->avanzar();
		}
	}
}

bool Barrio::existeVia(int cod) { //si encuentra la via en la lista de vias, devuelve true, si no false.
	bool enc = false;
	if (this->l != NULL) {
		Via *vaux;
		this->l->moverInicio();
		while (!this->l->finLista() && !enc) {
			this->l->consultar(vaux);
			if (vaux->getCodVia() == cod)
				enc = true;
			else
				this->l->avanzar();
		}
	}
	return enc;
}

//-------------------------------Módulos para algoritmo 2---------------------------------------------------------------------------------------------------------------------------
void Barrio::recorrerListaVia2(string genero, Cola<ColaArbol*>*& cA) {
	if (this->l != NULL) {
		Via *v;
		this->l->moverInicio();
		while (!this->l->finLista()) {
			this->l->consultar(v);
			v->recorrerListaArbol2(genero, cA);
			this->l->avanzar();
		}
	}
}

//-------------------------------Módulos para algoritmo 3-----------------------------------------------------------------------------------------------------------
void Barrio::cargarListaEspecieBarrio3(ListaPI<Especie*>* &lE) {

	Via *v;
	if (this->l != NULL) {
		this->l->moverInicio();

		while (!this->l->finLista()) {
			this->l->consultar(v);
			v->cargarListaEspecie3(lE);
			this->l->avanzar();
		}
	}
}

//--------------------------------Módulo para algoritmo 4-------------------------------------------------------------------------
int Barrio::cuantosArbolesVia() {
	Via*vaux;
	int cont = 0;
	if (this->l != NULL) {
		this->l->moverInicio();
		while (!this->l->finLista()) {
			this->l->consultar(vaux);
			cont += vaux->cuantosArboles();
			this->l->avanzar();
		}
	}
	return cont;
}

Barrio::~Barrio() {
	Via *v;
	if (this->l != NULL) {
		this->l->moverInicio();
		while (!this->l->finLista()) {
			this->l->consultar(v);
			this->l->borrar();
			delete v;
		}
	}
	delete this->l;

}
