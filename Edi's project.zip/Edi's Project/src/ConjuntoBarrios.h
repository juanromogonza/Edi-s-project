/*
 * ConjuntoBarrios.h
 *
 *  Created on: 12 mar. 2019
 *      Author: Juan Romo González
 */
#include "Barrio.h"
#ifndef CONJUNTOBARRIOS_H_
#define CONJUNTOBARRIOS_H_

class ConjuntoBarrios {
	Barrio *b[MAX]; //vector tamaño MAX que contiene en cada celda un puntero tipo Barrio
	int cont;

public:
	/*PRE:
	 * POST: Inicializa las variables declaradas en la clase a 0
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	ConjuntoBarrios();

	/*PRE: El puntero esté inicializado correctamente.
	 * POST: Llama al conjunto Barrio para insertar el barrio en orden.
	 * Complejidad: O(n*logn)
	 * Parámetros:
	 */
	void insertarBarrioEnOrden(Barrio *ba);

	/*PRE: Que la instancia no sea conjunto vacio (revisar)
	 * POST: Devuelve el contador de los barrios que hay en el vector
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	int cuantosBarrios();

	/*PRE: Que la instancia no sea conjunto vacio (revisar)
	 * POST: Devuelve false si no encuentra el barrio
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	bool estaVacioBarrios();

	/*PRE: Los atributos sean válidos.
	 * POST: Comprueba si un barrio existe o no. Devuelve true si existe, false en caso contrario.
	 * Complejidad: O(n*logn)
	 * Parámetros: nombre: nombre del barrio que se quiere comprobar
	 */
	bool existeBarrio(string nombre);

	/*PRE: Los atributos sean válidos.
	 * POST: Devuelve el elemento.
	 * Complejidad: O(1)
	 * Parámetros: pos: indica la posición del elemento a buscar.
	 */
	void obtenerBarrioPorPos(int pos, Barrio *&ba); //obtiene por parametros el barrio de la casilla del vector de la posicion indicada

	/*PRE: Los atributos sean válidos.
	 * POST: Devuelve el barrio que coincide con el nombre dado en la cabecera del módulo.
	 * Complejidad: O(n*logn)
	 * Parámetros: nombre: nombre del barrio que se quiere obtener
	 */
	void obtenerBarrioConcreto(string nombre, Barrio *&ba); //obtiene por parametros el barrio con el nombre que coincide

	/*PRE: Los atributos sean válidos.
	 * POST: Elimina el barrio el cual coincide con el nombre dado por parámetros.
	 * Complejidad: O(n)
	 * Parámetros: nombre: nombre del barrio que se quiere eliminar
	 */
	void eliminarBarrio(string nombre);

	/*PRE:
	 * POST:Libera memoria
	 * Complejidad: O(n)
	 * Parámetros:
	 */
	~ConjuntoBarrios();
};

#endif /* CONJUNTOBARRIOS_H_ */
