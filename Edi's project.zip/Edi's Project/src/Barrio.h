/*
 * Barrio.h
 *
 *  Created on: 12 mar. 2019
 *      Author: Juan Romo González
 */
#include "listapi.h"
#include "Via.h"

#ifndef BARRIO_H_
#define BARRIO_H_
const int MAX = 1900;
class Barrio {
	string nombre;
	float area;
	float perimetro;
	int codigo;
	string distrito;
	ListaPI<Via*>*l;

public:

	/*PRE:
	 * POST: Inicializa las variables declaradas en la clase a 0.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	Barrio();

	/*PRE: Los parámetros deben contener datos válidos.
	 * POST: Los atributos se inicializan correctamente.
	 * Complejidad: O(1).
	 * Parámetros: nombre: nombre del barrio.
	 * 			   area: área que abarca el barrio.
	 * 			   perimetro: perímetro del barrio.
	 * 			   codigo: cada barrio tiene un código asignado.
	 * 			   distrito: Distrito de cada barrio(Norte, sur, este y oeste).
	 */
	Barrio(string nombre, float area, float perimetro, int codigo,
			string distrito);

	/*PRE: El atributo contenga un dato válido.
	 * POST: Devuelve el nombre del barrio.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	const string& getNombre() const;

	/*PRE: Que entre por parámetros el nombre del barrio correctamente.
	 * POST: Asigna al nombre del barrio la variable de la cabecera.
	 * Complejidad: O(1)
	 * Parámetros: nombre: indicar el nombre del barrio.
	 */
	void setNombre(const string& nombre);

	/*PRE: El atributo contenga un dato válido.
	 * POST: Devuelve el área del barrio.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	float getArea() const;

	/*PRE: Que entre por parámetros el área del barrio correctamente.
	 * POST: Asigna al área del barrio la variable de la cabecera.
	 * Complejidad: O(1).
	 * Parámetros: area: indica el área que abarca el barrio.
	 */
	void setArea(float area);

	/*PRE: El atributo contenga un dato válido.
	 * POST: Devuelve el perímetro del barrio.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	float getPerimetro() const;

	/*PRE: Que entre por parámetros el nombre del barrio correctamente.
	 * POST: Asigna al perímetro del barrio la variable de la cabecera.
	 * Complejidad: O(1).
	 * Parámetros: perímetro: indicar el perímetro del barrio.
	 */
	void setPerimetro(float perimetro);

	/*PRE: El atributo contenga un dato válido.
	 * POST: Devuelve el código del barrio.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	int getCodigo() const;

	/*PRE: Que entre por parámetros el código del barrio correctamente.
	 * POST: Asigna al código del barrio la variable de la cabecera.
	 * Complejidad: O(1).
	 * Parámetros: codigo: indica el codigo del barrio.
	 */
	void setCodigo(int codigo);

	/*PRE: El atributo contenga un dato válido.
	 * POST: Devuelve el distrito del barrio.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	const string& getDistrito() const;

	/*PRE: Que entre por parámetros el distrito del barrio correctamente.
	 * POST: Asigna al distrito del barrio la variable de la cabecera.
	 * Complejidad: O(1).
	 * Parámetros: distrito: indicar el distrito del barrio.
	 */
	void setDistrito(const string& distrito);

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Muestra por pantalla el barrio  con sus vías.
	 * Complejidad: O(n).
	 * Parámetros:
	 */
	void mostrar();

//----------------------------------Modulos para la carga de datos-----------------------------------------------------------------

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Inserta en la lista l la vía v en órden alfabético.
	 * Complejidad: O(log(n)).
	 * Parámetros:
	 */
	void insertar(Via *v);

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Inserta el árbol que viene dado por parámetros en la vía cuyo código coincida con el del árbol.
	 * Complejidad: O(log(n)).
	 * Parámetros:
	 */
	void insertarArbolEnVia(Arbol *a);

//--------------------------------------Modulos algoritmo 1----------------------------------------------------------------------------------------------------

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Devuelve true si existe alguna vía con el código dado por parámetros, false en caso contrario.
	 * Complejidad: O(log(n)).
	 * Parámetros: cod: Código de la vía que se está buscando.
	 */
	bool existeVia(int cod);

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Queda en el punto de interés de la lista l apuntando a la vía que coincida con el parametro "nombre", poniendo a true el booleano "enc", false en caso contrario.
	 * Complejidad: O(log(n)).
	 * Parámetros:nombre: nombre de la via
	 * 			  v: puntero tipo Via
	 * 			  enc: booleano que indica si se ha encontrado la via o no
	 */
	void obtenerVia1(string nombre, Via *&v, bool &enc);

//--------------------------------------Modulos algoritmo 2---------------------------------------------------------------------------------------------------------------------

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Recorre la lista de vias cargando ordenadamente en una cola los arboles que necesitan poda tomando en cuenta su altura y el tamaño de su copa
	 * Complejidad: O(n*logn).
	 * Parámetros:cA: Cola de tipo struct ColaArbol
	 */
	void recorrerListaVia2(string genero, Cola<ColaArbol*>*&cA);

//--------------------------------------Modulos algoritmo 3-----------------------------------------------------------------------------------------------------------------

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Recorre la lista de vias cargando los datos de las especies de los arboles de cada via
	 * Complejidad: O(n³).
	 * Parámetros:lE: listaPI de tipo struct Especie
	 */
	void cargarListaEspecieBarrio3(ListaPI<Especie*>*&lE);

//--------------------------------------Modulos algoritmo 4--------------------------------------------------------------------------------------------------------

	/*PRE: Los atributos contengan un dato válido.
	 * POST: Devuelve el número total de árboles de una vía.
	 * Complejidad: O(n²)
	 * Parámetros:
	 */
	int cuantosArbolesVia();

//---------------------------------------Destructor---------------------------------------------------------------------------

	/*PRE:
	 * POST: Libera memoria.
	 * Complejidad: O(1).
	 * Parámetros:
	 */
	~Barrio();
};

#endif /* BARRIO_H_ */
