/*
 * Arbol.cpp
 *
 *  Created on: 9 abr. 2019
 *      Author: Juan Romo González
 */

#include "Arbol.h"

Arbol::Arbol() {
	this->altura = 0;
	this->codVia = 0;
	this->copa = 0;
	this->diametro = 0;
	this->especie = "";
	this->familia = "";
	this->genero = "";
	this->nombreComun = "";
	this->riego = "";
	this->unidad = 0;
}

Arbol::Arbol(string especie, string familia, string nombreComun, string genero,
		float diametro, float altura, float copa, string riego, int unidad,
		int codVia) {
	this->altura = altura;
	this->codVia = codVia;
	this->copa = copa;
	this->diametro = diametro;
	this->especie = especie;
	this->familia = familia;
	this->genero = genero;
	this->nombreComun = nombreComun;
	this->riego = riego;
	this->unidad = unidad;
}

float Arbol::getAltura() const {
	return altura;
}

void Arbol::setAltura(float altura) {
	this->altura = altura;
}

int Arbol::getCodVia() const {
	return codVia;
}

void Arbol::setCodVia(int codVia) {
	this->codVia = codVia;
}

float Arbol::getCopa() const {
	return copa;
}

void Arbol::setCopa(float copa) {
	this->copa = copa;
}

float Arbol::getDiametro() const {
	return diametro;
}

void Arbol::setDiametro(float diametro) {
	this->diametro = diametro;
}

const string& Arbol::getEspecie() const {
	return especie;
}

void Arbol::setEspecie(const string& especie) {
	this->especie = especie;
}

const string& Arbol::getFamilia() const {
	return familia;
}

void Arbol::setFamilia(const string& familia) {
	this->familia = familia;
}

const string& Arbol::getGenero() const {
	return genero;
}

void Arbol::setGenero(const string& genero) {
	this->genero = genero;
}

const string& Arbol::getNombreComun() const {
	return nombreComun;
}

void Arbol::setNombreComun(const string& nombreComun) {
	this->nombreComun = nombreComun;
}

const string& Arbol::getRiego() const {
	return riego;
}

void Arbol::setRiego(const string& riego) {
	this->riego = riego;
}

int Arbol::getUnidad() const {
	return unidad;
}

void Arbol::setUnidad(int unidad) {
	this->unidad = unidad;
}

void Arbol::mostrar() {
	cout << "Genero: " << this->genero << " Diámetro: " << this->diametro
			<< " Altura: " << this->altura << " Copa: " << this->copa
			<< " Unidades: " << this->unidad << " Vía: " << this->codVia << endl
			<< endl;
}

Arbol::~Arbol() {

}

