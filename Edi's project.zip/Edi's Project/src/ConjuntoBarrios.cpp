/*
 * ConjuntoBarrios.cpp
 *
 *  Created on: 12 mar. 2019
 *      Author: Juan Romo González
 */

#include "ConjuntoBarrios.h"

ConjuntoBarrios::ConjuntoBarrios() {
	this->cont = 0;
}

void ConjuntoBarrios::insertarBarrioEnOrden(Barrio* ba) {
	Barrio *b2;
	int i = 0;
	bool enc = false;
	if (this->cont < MAX) {
		if (ba != NULL) {
			while (i < this->cont && !enc) {
				b2 = this->b[i];
				if (b2->getNombre() > ba->getNombre()) {
					enc = true;
				}
				if (b2->getNombre() > ba->getNombre()) {
					if (b2->getCodigo() > ba->getCodigo())
						enc = true;
				}
				if (!enc)
					i++;
			}
			//En este punto el indice marca la posicion donde se va a insertar
			for (int j = this->cont; j > i; --j) {
				this->b[j] = this->b[j - 1];
			}
			this->b[i] = ba;
			this->cont++;
		}
	}
}

int ConjuntoBarrios::cuantosBarrios() {
	return this->cont;
}

bool ConjuntoBarrios::estaVacioBarrios() {
	return this->cont == 0;
}

bool ConjuntoBarrios::existeBarrio(string nombre) {
	bool enc = false;
	int i = 0;
	Barrio *b2;
	while (i < this->cont && !enc) {
		b2 = this->b[i];
		if (b2->getNombre() == this->b[i]->getNombre()) {
			enc = true;
		} else
			i++;
	}
	return enc;
}

void ConjuntoBarrios::obtenerBarrioPorPos(int pos, Barrio*& ba) {
	if (pos >= 0 && pos < this->cont)
		ba = this->b[pos];
}

void ConjuntoBarrios::obtenerBarrioConcreto(string nombre, Barrio*& ba) {
	bool enc = false;
	int i = 0;
	Barrio *b2; //puntero auxiliar
	while (i < this->cont && !enc) {
		b2 = this->b[i];
		if (b2->getNombre() == nombre) {
			enc = true;
			ba = b2;
		} else
			i++;
	}
}

void ConjuntoBarrios::eliminarBarrio(string nombre) {
	int e = 0;
	Barrio *b2;
	for (int i = 0; i < this->cont; i++) {
		b2 = this->b[i];
		if (b2->getNombre() == nombre) {
			e++;
			delete this->b[i];
		}
		this->b[i] = this->b[i + e];
	}
	if (e != 0)
		this->cont--;
}

ConjuntoBarrios::~ConjuntoBarrios() { //el destructor recorre todos el vector eliminando la memoria a la que apuntan los punteros, dejandolos a NULL
	for (int i = 0; i < this->cont; i++) {
		if (this->b[i] != NULL)
			delete this->b[i];
	}
	this->cont = 0;
}
