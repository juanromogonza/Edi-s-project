/*
 * Arbol.h
 *
 *  Created on: 9 abr. 2019
 *      Author: Juan Romo González
 */

#ifndef ARBOL_H_
#define ARBOL_H_

#include <iostream>
using namespace std;

class Arbol {
	string especie;
	string familia;
	string nombreComun;
	string genero;
	float diametro;
	float altura;
	float copa;
	string riego;
	int unidad;
	int codVia;

public:

	/*PRE:
	 * POST: Inicializa las variables declaradas en la clase a 0
	 * Complejidad:O(1)
	 * Parametros:
	 */
	Arbol();

	/*PRE: Los parametros deben estar correctamente inicializados
	 * POST: Inicializa las variables de la clase con los valores que se pasan por parametros
	 * Complejidad:O(1)
	 * Parametros: especie: especie del arbol (nombre cientifico(en latín))
	 * 			   familia: familia a la que pertenece el arbol
	 * 			   nombreComun: nombre comun del arbol
	 * 			   genero: genero del arbol (en latín y mayusculas)
	 * 			   diametro: diametro del arbol
	 * 			   altura: altura que alcanza el arbol
	 * 			   copa: tamaño de la copa del arbol
	 * 			   riego: metodo de riego del arbol y si lo necesita o no (en mayusculas)
	 * 			   unidad: numero de arboles de este tipo que hay en la via
	 * 			   codVia: codigo de la via en la que se encuentra este ejemplar de arbol
	 */
	Arbol(string especie, string familia, string nombreComun, string genero,
			float diametro, float altura, float copa, string riego, int unidad,
			int codVia);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el la altura del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	float getAltura() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna a la altura la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: altura: altura del arbol
	 */
	void setAltura(float altura);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el código de la via
	 * Complejidad:O(1)
	 * Parametros:
	 */
	int getCodVia() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al código de la via la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: codVia: codigo de la via en la que esta el arbol
	 */
	void setCodVia(int codVia);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el tamaño de la copa del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	float getCopa() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna a la copa la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: copa: tamaño de la copa del arbol
	 */
	void setCopa(float copa);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el diametro del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	float getDiametro() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al diametro la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: diametro: diametro del arbol
	 */
	void setDiametro(float diametro);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve la especie del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	const string& getEspecie() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna a la especie la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: especie: especie del arbol
	 */
	void setEspecie(const string& especie);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve la familia a la que pertenece el arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	const string& getFamilia() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna a la familia la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: familia: familia a la que pertenece el arbol
	 */
	void setFamilia(const string& familia);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el genero del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	const string& getGenero() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al genero del arbol la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: genero: genero del arbol
	 */
	void setGenero(const string& genero);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el nombre comun por el que se conoce al arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	const string& getNombreComun() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al nombre del arbol la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: nombreComun: nombre comun por el que se conoce el arbol
	 */
	void setNombreComun(const string& nombreComun);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el metodo de riego del arbol
	 * Complejidad:O(1)
	 * Parametros:
	 */
	const string& getRiego() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al metodo de riego la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: riego: metodo de riego que tiene el arbol (si lo necesita)
	 */
	void setRiego(const string& riego);

	/*PRE: El atributo contenga un dato válido
	 * POST: Devuelve el numero de unidades del arbol en esa via
	 * Complejidad:O(1)
	 * Parametros:
	 */
	int getUnidad() const;

	/*PRE: Que entre por parámetros de entrada el nombre de la vía que se le va a asignar correctamente
	 * POST: Asigna al numero de unidades la variable de la cabecera.
	 * Complejidad:O(1)
	 * Parametros: unidad: numero de arboles del mismo tipo que hay en la misma via
	 */
	void setUnidad(int unidad);

	/*PRE: Los atributos contengan datos válidos
	 * POST: Muestra por pantalla las variables de la clase Árbol
	 * Complejidad: O(1)
	 * Parámetros:
	 */
	void mostrar();

	/*PRE:
	 * POST: Libera memoria
	 * Complejidad:O(1)
	 * Parametros:
	 */
	~Arbol();
};

#endif /* ARBOL_H_ */
