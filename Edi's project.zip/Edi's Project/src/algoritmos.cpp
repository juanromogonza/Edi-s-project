/*
 * Algoritmos.cpp
 *
 *  Created on: 02/03/2019
 *      Author: Profesores de EDI
 */

#include "algoritmos.h"

using namespace std;

// MAIN function
int main() {
	Algoritmos Algoritmos;
	return 0;
}

// ******************** PRIVATE OPERATIONS ********************

void Algoritmos::run() {

	cout
			<< "----------------------- Mostrando todos los barrios----------------------- "
			<< endl << endl;
	mostrarBarrios();

	cout
			<< "----------------------- Ejecutando algoritmo 1----------------------- "
			<< endl << endl;
	this->algoritmo1("Gredos");
	cout << "----------------------- Fin algoritmo 1----------------------- "
			<< endl << endl;

	cout
			<< "----------------------- Ejecutando algoritmo 2----------------------- "
			<< endl << endl;
	this->algoritmo2("ACACIA");
	cout << "----------------------- Fin algoritmo 2----------------------- "
			<< endl << endl;
	cout
			<< "----------------------- Ejecutando algoritmo 3----------------------- "
			<< endl << endl;
	this->algoritmo3();
	cout << "----------------------- Fin algoritmo 3----------------------- "
			<< endl << endl;
	cout
			<< "----------------------- Ejecutando algoritmo 4----------------------- "
			<< endl << endl;
	this->algoritmo4();
	cout << "----------------------- Fin algoritmo 4----------------------- "
			<< endl << endl;
	;
//	cout
//			<< "----------------------- Ejecutando juego pruebas----------------------- "
//			<< endl;
//	this->JuegoPruebas();
//	cout << "----------------------- Fin juego pruebas----------------------- "
//			<< endl;
}

void Algoritmos::cargarDatos() {
	this->cargarBarrios();
	this->cargarVias();
	this->cargarArbolesFichero();
}

// ******************** PUBLIC INTERFACE ********************

Algoritmos::Algoritmos() {

	cout << "Programming Project v2.00 (EDI)." << endl;
	cout << "           Author: David Barroso Moro Adrián Barquilla Rodríguez."
			<< endl;
	cout << "           Date:   April 3th, 2019." << endl;

	this->cB = new ConjuntoBarrios();
	cout << "----------------------- Cargando Datos----------------------- "
			<< endl << endl;
	this->cargarDatos();
	this->run();
}
//------------------------------------Algoritmo de carga de datos--------------------------------------
void Algoritmos::cargarArboles(Arbol *a) {
	bool enc = false;
	Barrio *b2;

	int i = 0;
	while (i < this->cB->cuantosBarrios() && !enc) {
		this->cB->obtenerBarrioPorPos(i, b2);
		if (b2->existeVia(a->getCodVia())) {
			b2->insertarArbolEnVia(a);
			enc = true;
		} else
			i++;
	}
}

void Algoritmos::cargarViaEnBarrio(Via* v) {
	Barrio *b;
	int i = 0;
	bool enc = false;
	while (i < this->cB->cuantosBarrios() && !enc) {
		this->cB->obtenerBarrioPorPos(i, b);
		if (b->getCodigo() == v->getCodBarrio()) {
			enc = true;
			b->insertar(v);

		} else
			i++;
	}
}

void Algoritmos::cargarArbolesFichero() {
	ifstream flujo("Arbol.csv");
	string linea[10];
	if (flujo.is_open()) {
		getline(flujo, linea[0]);
		while (!flujo.eof()) {
			getline(flujo, linea[0], ';');
			if (!flujo.eof()) {
				getline(flujo, linea[1], ';');
				getline(flujo, linea[2], ';');
				getline(flujo, linea[3], ';');
				getline(flujo, linea[4], ';');
				getline(flujo, linea[5], ';');
				getline(flujo, linea[6], ';');
				getline(flujo, linea[7], ';');
				getline(flujo, linea[8], ';');
				getline(flujo, linea[9]);
				Arbol *a = new Arbol(linea[0], linea[1], linea[2], linea[3],
						atof(linea[4].c_str()), atof(linea[5].c_str()),
						atof(linea[6].c_str()), linea[7],
						atoi(linea[8].c_str()), atoi(linea[9].c_str()));
				this->cargarArboles(a);
			}
		}
	}
}

void Algoritmos::cargarVias() {
	ifstream flujo("Via.csv");
	string linea[5];
	if (flujo.is_open()) {
		getline(flujo, linea[0]);
		while (!flujo.eof()) {
			getline(flujo, linea[0], ';');
			if (!flujo.eof()) {
				getline(flujo, linea[1], ';');
				getline(flujo, linea[2], ';');
				getline(flujo, linea[3], ';');
				getline(flujo, linea[4]);
				Via *v = new Via(atoi(linea[0].c_str()), linea[1],
						atof(linea[2].c_str()), linea[3],
						atoi(linea[4].c_str()));
				this->cargarViaEnBarrio(v);

			}
		}
		flujo.close();
	} else
		cout << "ERROR AL ABRIR EL FICHERO VIA" << endl;
}

void Algoritmos::cargarBarrios() {
	ifstream flujo("Barrio.csv");
	string linea[5];
	if (flujo.is_open()) {
		getline(flujo, linea[0]);
		while (!flujo.eof()) {
			getline(flujo, linea[0], ';');
			if (!flujo.eof()) {
				getline(flujo, linea[1], ';');
				getline(flujo, linea[2], ';');
				getline(flujo, linea[3], ';');
				getline(flujo, linea[4]);
				Barrio *b = new Barrio(linea[0], atof(linea[1].c_str()),
						atof(linea[2].c_str()), atoi(linea[3].c_str()),
						linea[4]);
				this->cB->insertarBarrioEnOrden(b);

			}
		}
		flujo.close();
	} else
		cout << "ERROR AL ABRIR EL FICHERO BARRIO" << endl;
}

void Algoritmos::mostrarBarrios() {
	Barrio *b;
	for (int i = 0; i < this->cB->cuantosBarrios(); i++) {
		this->cB->obtenerBarrioPorPos(i, b);
		b->mostrar();
		cout << endl;
	}
}

//-----------------------------------Algoritmo 1----------------------------------------------
void Algoritmos::generarFicheroArboles1(string nombreVia) {
	int i = 0;
	Barrio *baux;
	Via *vaux;
	bool enc = false;

	while (i < this->cB->cuantosBarrios() && !enc) {
		this->cB->obtenerBarrioPorPos(i, baux);
		baux->obtenerVia1(nombreVia, vaux, enc);
		i++;
	}

}

//------------------------Algoritmo 2------------------------------------------------------

void Algoritmos::arbolesAPodar2(string genero) {
	Cola<ColaArbol*> *cA = new Cola<ColaArbol*>();
	Barrio *b;

	for (int i = 0; i < this->cB->cuantosBarrios(); i++) {
		this->cB->obtenerBarrioPorPos(i, b);
		b->recorrerListaVia2(genero, cA);
	}
	this->mostrarAlgoritmo2(cA);
	delete cA;
}

void Algoritmos::mostrarAlgoritmo2(Cola<ColaArbol*>*& cA) {
	ColaArbol *ac;
	if (!cA->vacia()) {
		cA->primero(ac);
		cA->desencolar();
		cout << "Via: " << ac->nombreVia << " ";
		ac->a->mostrar();
		delete ac;
		this->mostrarAlgoritmo2(cA);
	}
}
//------------------------Algoritmo 3------------------------------------------------------

void Algoritmos::generarFicheroNumeroArboles3() {
	ofstream f("Total Arboles.txt");
	Barrio *b;
	Especie *e;
	int cont = 0;
	ListaPI<Especie*>*lE = new ListaPI<Especie*>();
	if (f.is_open()) {
		for (int i = 0; i < this->cB->cuantosBarrios(); ++i) {
			this->cB->obtenerBarrioPorPos(i, b);
			b->cargarListaEspecieBarrio3(lE);
		}
		lE->moverInicio();
		while (!lE->finLista()) {

			lE->consultar(e);
			f << e->especie;
			f << "................";
			f << e->cont << endl;
			cont += e->cont;
			delete e;
			lE->avanzar();
		}

		f << "Total número de árboles: " << cont << endl;
		f.close();
	}
	delete lE;
}

//------------------------Algoritmo 4------------------------------------------------------

void Algoritmos::mostrarNumeroArbolesEnBarrio4() {
	int i;
	Barrio *baux; //auxiliar

	for (i = 0; i < this->cB->cuantosBarrios(); i++) {
		this->cB->obtenerBarrioPorPos(i, baux);
		cout << baux->getNombre() << " ...................Nº de Arboles: "
				<< baux->cuantosArbolesVia() << endl;
	}
}

//------------------------------------Llamadas a algoritmos-------------------------------------------

void Algoritmos::algoritmo1(string nombreVia) {
	this->generarFicheroArboles1(nombreVia);
}

void Algoritmos::algoritmo2(string genero) {
	this->arbolesAPodar2(genero);
}

void Algoritmos::algoritmo3() {
	this->generarFicheroNumeroArboles3();
}

void Algoritmos::algoritmo4() {
	this->mostrarNumeroArbolesEnBarrio4();
}

//------------------------------------Módulos de prueba-------------------------------------------

void Algoritmos::pruebaBarrioInsertarArbolenVia() { //modulo para la carga de datos
	cout << "Ejecutando pruebas InsertarArbolEnVia" << endl;
	//Debe insertar el árbol a en la vía cuyo codigo de via coincida.
	Barrio *b;
	this->cB->obtenerBarrioConcreto("Seminario", b);
	Arbol *a = new Arbol("Acacia", "aa", "David", "Masculino", 32.2, 243, 3,
			"No riego", 3763, 33);

	b->insertarArbolEnVia(a);
	delete a;
}

void Algoritmos::pruebaBarrioExisteVia() {
	cout << "Ejecutando pruebas existeVia" << endl;
	Barrio *b;
	this->cB->obtenerBarrioConcreto("Seminario", b);
	//Si devuelve false, el módulo falla, si devuelve true, el módulo está correctamente implementado.
	if (b->existeVia(3763))
		cout << "Error en existeVia" << endl;
}

void Algoritmos::pruebaBarrioInsertar() {
	Via *v;
	cout << "Ejecutando pruebas Barrio insertar" << endl;
	//Debe insertar la via V en el barrio cuyo codigo coincida.
	Barrio *b;
	this->cB->obtenerBarrioConcreto("Seminario", b);
	v = new Via(12, "David", 3232.2, "calle", 3763);
	b->insertar(v);
}

void Algoritmos::pruebaBarrioCuantosArboles() { //pruebas listas de barrio y vias
	Barrio *b;
	cout << "Ejecutando pruebas Barrio y Via cuantosArboles" << endl;
	this->cB->obtenerBarrioConcreto("Macondo", b);
	if (b->cuantosArbolesVia() != 418)
		cout << "Fallo en CuantosArboles" << endl;
}

void Algoritmos::JuegoPruebas() {
	this->pruebaBarrioCuantosArboles();
	this->pruebaBarrioExisteVia();
	this->pruebaBarrioInsertar();
	this->pruebaBarrioInsertarArbolenVia();
}

void Algoritmos::pruebaViaInsertarArbol() {
	cout << "Iniciando Prueba InsertarArbol" << endl;
	Via *v;
	Arbol *a;
	a = new Arbol("acer", "arbol", "Acer", "macho", 2.5, 3.3, 1.1, "No riego",
			1, 839);
	v->insertarArbol(a);

	cout << "Fin prueba InsertarArbol" << endl;
}

void Algoritmos::pruebaViaCargarArbolesEnFichero() {
	cout << "Iniciando Prueba CargarArbolesEnFichero1" << endl;
	Via*v;
	Arbol*a;
	a = new Arbol("acer", "arbol", "Acer", "macho", 2.5, 3.3, 1.1, "No riego",
			1, 839);
	//Debe insertar el árbol a en la vía v y cargarla en el fichero
	v->insertarArbol(a);
	v->cargarArbolesEnFichero1();

	cout << "Fin Prueba CargarArbolesEnFichero" << endl;
}

void Algoritmos::pruebaBarrioRecorrerListaVia() {
	cout << "Iniciando pruebas RecorrerListaVia" << endl;
//Debe meter una lista de arboles que necesiten poda y recorrerla con el modulo
	Barrio *b;
	Cola<ColaArbol*>*cA=new Cola<ColaArbol*>();
	this->cB->obtenerBarrioConcreto("Macondo", b);
	b->recorrerListaVia2("ACER",cA);
	cout << "Fin pruebas RecorrerListaVia" << endl;
}

void Algoritmos::pruebaBarrioCargarListaEspecie() {
	Barrio *b;
	cout << "Iniciando pruebas CargarListaEspecie" << endl;
	ofstream f("Total Arboles.txt");
	ListaPI<Especie*> *e = new ListaPI<Especie*>();
	if (f.is_open()) {
		this->cB->obtenerBarrioConcreto("Macondo", b);
		b->cargarListaEspecieBarrio3(e);
	}

	f.close();
}

//-----------------------------------------------Destructor------------------------------------------------------------
Algoritmos::~Algoritmos() {
	delete this->cB;
}

